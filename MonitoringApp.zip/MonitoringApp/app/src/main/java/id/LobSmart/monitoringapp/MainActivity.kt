package id.LobSmart.monitoringapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.*
import kotlin.Exception

class MainActivity : AppCompatActivity() {

    private lateinit var tvTempValue: TextView
    private lateinit var tvTdsValue: TextView
    private lateinit var tvPhValue: TextView

    private lateinit var mqttAndroidClient: MqttAndroidClient

    private val serverUri = "tcp://broker.hivemq.com:1883" // Ganti dengan broker kamu
    private val clientId = MqttClient.generateClientId()
    private val temperatureTopic = "0897_water_monitoring/temp"
    private val tdsTopic = "0897_water_monitoring/tds"
    private val phTopic = "0897_water_monitoring/ph"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi TextView
        tvTempValue = findViewById(R.id.tvTempValue)
        tvTdsValue = findViewById(R.id.tvTdsValue)
        tvPhValue = findViewById(R.id.tvPhValue)

        // Inisialisasi MQTT Client
        mqttAndroidClient = MqttAndroidClient(applicationContext, serverUri, clientId)
        connectMqtt()
    }

    private fun connectMqtt() {
        try {
            val options = MqttConnectOptions().apply {
                isAutomaticReconnect = true
                isCleanSession = false
            }

            mqttAndroidClient.connect(options, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d("MQTT", "Connected to: $serverUri")
                    subscribeToTopics()
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.d("MQTT", "Failed to connect to: $serverUri")
                }
            })

            mqttAndroidClient.setCallback(object : MqttCallbackExtended {
                override fun connectComplete(reconnect: Boolean, serverURI: String?) {
                    Log.d("MQTT", "Connection complete.")
                }

                override fun connectionLost(cause: Throwable?) {
                    Log.d("MQTT", "Connection lost.")
                }

                @Throws(Exception::class)
                override fun messageArrived(topic: String?, message: MqttMessage?) {
                    val payload = message?.payload?.let { String(it) }
                    when (topic) {
                        temperatureTopic -> tvTempValue.text = "$payload°C"
                        tdsTopic -> tvTdsValue.text = "$payload ppm"
                        phTopic -> tvPhValue.text = payload
                    }
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) {}
            })

        } catch (ex: MqttException) {
            ex.printStackTrace()
        }
    }

    private fun subscribeToTopics() {
        try {
            mqttAndroidClient.subscribe(temperatureTopic, 0)
            mqttAndroidClient.subscribe(tdsTopic, 0)
            mqttAndroidClient.subscribe(phTopic, 0)
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }
}